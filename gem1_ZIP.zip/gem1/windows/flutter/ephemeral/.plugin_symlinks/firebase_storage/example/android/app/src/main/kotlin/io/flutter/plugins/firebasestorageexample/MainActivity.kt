package io.flutter.plugins.firebasestorageexample

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
