import 'package:flutter/material.dart';
import 'package:gem1/features/user_auth/presentation/pages/login_page.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginPage(), // Replace with your initial page widget
      routes: {
        '/home': (context) => MyHomePage(),
        '/login': (context) => LoginPage(), // Define other routes here
        // Add other routes as needed
      },
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home Page"),
      ),
      body: Center(
        child: Text("Welcome to My App!"),
      ),
    );
  }
}
